import { useEffect, useState } from 'react';
import { Fingerprint, X, AlertCircle } from 'lucide-react';
import { authenticateBiometric, getBiometricTypeName } from '../lib/biometricAuth';
import { useAuth } from '../contexts/AuthContext';

interface BiometricConfirmModalProps {
  isOpen: boolean;
  title: string;
  description: string;
  onConfirm: () => void;
  onCancel: () => void;
}

export function BiometricConfirmModal({
  isOpen,
  title,
  description,
  onConfirm,
  onCancel,
}: BiometricConfirmModalProps) {
  const { user } = useAuth();
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [biometricType, setBiometricType] = useState('Biometria');

  useEffect(() => {
    if (isOpen) {
      setBiometricType(getBiometricTypeName());
      setError(null);
      // Auto-trigger biometric authentication when modal opens
      handleBiometricAuth();
    }
  }, [isOpen]);

  const handleBiometricAuth = async () => {
    if (!user) {
      setError('Usuário não autenticado');
      return;
    }

    setIsAuthenticating(true);
    setError(null);

    try {
      const success = await authenticateBiometric(user.uid);
      
      if (success) {
        // Success! Call the confirm callback
        onConfirm();
      }
    } catch (error: any) {
      console.error('❌ Biometric authentication error:', error);
      
      if (error.message?.includes('cancelled')) {
        setError('Autenticação cancelada');
      } else if (error.message?.includes('not registered')) {
        setError('Biometria não configurada');
      } else {
        setError('Falha na autenticação biométrica');
      }
    } finally {
      setIsAuthenticating(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-black/80 backdrop-blur-sm"
        onClick={onCancel}
      />

      {/* Modal */}
      <div className="relative w-full max-w-md mx-4 mb-4 sm:mb-0 bg-zinc-900 rounded-3xl overflow-hidden shadow-2xl border border-white/10 animate-slide-up">
        {/* Header */}
        <div className="px-6 py-5 border-b border-white/5 flex items-center justify-between">
          <h2 className="text-xl text-white">{title}</h2>
          <button
            onClick={onCancel}
            className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-white/5 transition-colors"
          >
            <X className="w-5 h-5 text-white/70" />
          </button>
        </div>

        {/* Content */}
        <div className="px-6 py-8">
          {/* Biometric Icon */}
          <div className="flex justify-center mb-6">
            <div className={`w-20 h-20 rounded-full flex items-center justify-center ${
              isAuthenticating 
                ? 'bg-white/10 animate-pulse' 
                : error
                ? 'bg-red-500/20'
                : 'bg-white/10'
            }`}>
              {error ? (
                <AlertCircle className="w-10 h-10 text-red-500" />
              ) : (
                <Fingerprint className={`w-10 h-10 ${
                  isAuthenticating ? 'text-white animate-pulse' : 'text-white/70'
                }`} />
              )}
            </div>
          </div>

          {/* Description */}
          <p className="text-center text-white/70 mb-6">
            {description}
          </p>

          {/* Status */}
          <div className="text-center mb-6">
            {isAuthenticating ? (
              <p className="text-sm text-white/50">
                Aguardando {biometricType}...
              </p>
            ) : error ? (
              <p className="text-sm text-red-500">{error}</p>
            ) : (
              <p className="text-sm text-white/50">
                Toque no sensor para confirmar
              </p>
            )}
          </div>

          {/* Actions */}
          <div className="space-y-3">
            {error && (
              <button
                onClick={handleBiometricAuth}
                disabled={isAuthenticating}
                className="w-full py-4 bg-white text-black rounded-2xl font-medium hover:bg-white/90 transition-colors disabled:opacity-50"
              >
                Tentar Novamente
              </button>
            )}
            
            <button
              onClick={onCancel}
              className="w-full py-4 bg-white/5 text-white rounded-2xl hover:bg-white/10 transition-colors"
            >
              Cancelar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

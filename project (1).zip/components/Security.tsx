import {
  ArrowLeft,
  Lock,
  Smartphone,
  Mail,
  Shield,
  Eye,
  Fingerprint,
  KeyRound,
  ChevronRight,
  AlertTriangle,
  MapPin,
  Camera,
  RotateCcw
} from 'lucide-react';
import { useState } from 'react';
import type { Screen } from '../App';
import { BiometricSettings } from './BiometricSettings';
import { useAuth } from '../contexts/AuthContext';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { toast } from 'sonner';

interface SecurityProps {
  onNavigate: (screen: Screen) => void;
}

export function Security({ onNavigate }: SecurityProps) {
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false);
  const [emailNotifications, setEmailNotifications] = useState(true);
  const { userData } = useAuth();
  const [isResetting, setIsResetting] = useState(false);

  // Função para resetar permissões e forçar nova solicitação
  const handleResetPermissions = async () => {
    if (!userData?.userId) return;
    
    setIsResetting(true);
    try {
      const userRef = doc(db, 'users', userData.userId);
      await updateDoc(userRef, {
        permissionsRequested: false,
        locationPermission: null,
        cameraPermission: null,
        permissionsRequestedAt: null
      });
      
      toast.success('Permissões resetadas! Faça logout e login novamente para testar.');
      console.log('✅ Permissões resetadas no Firestore');
    } catch (error) {
      console.error('Erro ao resetar permissões:', error);
      toast.error('Erro ao resetar permissões');
    } finally {
      setIsResetting(false);
    }
  };

  // Função para forçar solicitação de permissões AGORA
  const handleRequestPermissionsNow = async () => {
    console.log('🔐 Forçando solicitação de permissões AGORA...');
    
    try {
      // Localização
      console.log('📍 Solicitando localização...');
      
      const locationPromise = new Promise((resolve) => {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            console.log('✅ Localização concedida:', position.coords);
            toast.success('Localização permitida!');
            resolve('granted');
          },
          (error) => {
            console.log('❌ Localização negada:', error.message);
            
            if (error.code === 1) {
              toast.error('Localização bloqueada. Veja as instruções abaixo.');
              resolve('denied');
            } else if (error.code === 2) {
              toast.error('Localização indisponível no dispositivo');
              resolve('unavailable');
            } else {
              toast.error('Timeout ao obter localização');
              resolve('timeout');
            }
          },
          {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 0
          }
        );
      });

      await locationPromise;
      
      // Aguardar 1s
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Câmera
      console.log('📷 Solicitando câmera...');
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ 
          video: { facingMode: 'user' },
          audio: false 
        });
        console.log('✅ Câmera concedida');
        toast.success('Câmera permitida!');
        stream.getTracks().forEach(track => track.stop());
      } catch (error: any) {
        console.log('⚠️ Câmera não permitida:', error.name);
        
        if (error.name === 'NotAllowedError') {
          toast.error('Câmera bloqueada pelo navegador');
        } else if (error.name === 'NotFoundError') {
          toast.error('Nenhuma câmera encontrada');
        } else if (error.name === 'NotReadableError') {
          toast.error('Câmera em uso por outro app');
        } else if (error.name === 'NotSupportedError') {
          toast.error('Requer conexão HTTPS segura');
        } else {
          toast.error('Erro ao acessar câmera');
        }
        // NÃO mostrar erro técnico no console
      }
      
    } catch (error: any) {
      console.error('❌ Erro:', error);
      toast.error('Erro ao solicitar permissões');
    }
  };

  const securityItems = [
    {
      title: 'Autenticação',
      items: [
        {
          icon: Lock,
          label: 'Alterar senha',
          description: 'Última alteração há 3 meses',
          action: () => onNavigate('changePassword'),
          type: 'button' as const
        },
        {
          icon: Smartphone,
          label: 'Autenticação de dois fatores',
          description: 'Adicione uma camada extra de segurança',
          action: () => setTwoFactorEnabled(!twoFactorEnabled),
          type: 'toggle' as const,
          enabled: twoFactorEnabled
        }
      ]
    },
    {
      title: 'Notificações de segurança',
      items: [
        {
          icon: Mail,
          label: 'Alertas por e-mail',
          description: 'Receba notificações de atividades suspeitas',
          action: () => setEmailNotifications(!emailNotifications),
          type: 'toggle' as const,
          enabled: emailNotifications
        },
        {
          icon: AlertTriangle,
          label: 'Atividades recentes',
          description: 'Veja dispositivos e acessos recentes',
          action: () => {},
          type: 'button' as const
        }
      ]
    },
    {
      title: 'Privacidade',
      items: [
        {
          icon: Eye,
          label: 'Dispositivos conectados',
          description: '3 dispositivos ativos',
          action: () => {},
          type: 'button' as const
        },
        {
          icon: KeyRound,
          label: 'Sessões ativas',
          description: 'Gerencie suas sessões',
          action: () => {},
          type: 'button' as const
        }
      ]
    },
    {
      title: 'Biometria',
      items: [
        {
          icon: Shield,
          label: 'Teste Biométrico',
          description: 'Teste sua autenticação biométrica',
          action: () => {},
          type: 'button' as const
        }
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      {/* Header */}
      <header className="px-6 pt-6 pb-4 flex items-center gap-4">
        <button
          onClick={() => onNavigate('profile')}
          className="w-10 h-10 rounded-full bg-white/5 backdrop-blur-md border-2 border-white/20 flex items-center justify-center active:scale-95 transition-transform shadow-[0_0_20px_rgba(255,255,255,0.05),0_4px_15px_rgba(0,0,0,0.4),inset_0_1px_1px_rgba(255,255,255,0.15),inset_0_-1px_1px_rgba(0,0,0,0.25)]"
        >
          <ArrowLeft className="w-5 h-5 font-light" />
        </button>
        <h1 className="text-xl">Segurança</h1>
      </header>

      {/* Content */}
      <div className="flex-1 overflow-y-auto pb-24 px-6">
        {/* Security Alert */}
        <div className="bg-green-500/10 border border-green-500/20 rounded-2xl p-4 mb-6 backdrop-blur-md">
          <div className="flex items-start gap-3">
            <Shield className="w-5 h-5 text-green-500 mt-0.5" />
            <div className="flex-1">
              <h3 className="mb-1">Sua conta está protegida</h3>
              <p className="text-sm text-gray-400">
                Continue mantendo suas informações seguras
              </p>
            </div>
          </div>
        </div>

        {/* Security Sections */}
        <div className="space-y-6">
          {/* Biometric Settings Section */}
          <div>
            <h3 className="text-xs text-gray-400 mb-2 px-1">
              Biometria
            </h3>
            <BiometricSettings />
          </div>

          {securityItems.map((section, idx) => (
            <div key={idx}>
              <h3 className="text-xs text-gray-400 mb-2 px-1">
                {section.title}
              </h3>
              <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl overflow-hidden shadow-[0_0_20px_rgba(255,255,255,0.05),0_4px_15px_rgba(0,0,0,0.4),inset_0_1px_1px_rgba(255,255,255,0.15),inset_0_-1px_1px_rgba(0,0,0,0.25)]">
                {section.items.map((item, itemIdx) => {
                  const Icon = item.icon;
                  return (
                    <div key={item.label}>
                      <button
                        onClick={item.action}
                        className="w-full px-4 py-3 flex items-center justify-between hover:bg-white/10 transition-colors"
                      >
                        <div className="flex items-center gap-3 flex-1">
                          <Icon className="w-5 h-5 text-gray-400" />
                          <div className="flex-1 text-left">
                            <div className="text-white">{item.label}</div>
                            <div className="text-xs text-gray-400 mt-0.5">
                              {item.description}
                            </div>
                          </div>
                        </div>
                        {item.type === 'toggle' ? (
                          <div
                            className={`w-12 h-6 rounded-full transition-colors ${
                              item.enabled ? 'bg-green-500' : 'bg-zinc-700'
                            }`}
                          >
                            <div
                              className={`w-5 h-5 bg-white rounded-full mt-0.5 transition-transform ${
                                item.enabled ? 'translate-x-6' : 'translate-x-0.5'
                              }`}
                            />
                          </div>
                        ) : (
                          <ChevronRight className="w-5 h-5 text-gray-400" />
                        )}
                      </button>
                      {itemIdx < section.items.length - 1 && (
                        <div className="h-px bg-white/10 mx-4" />
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* Security Tips */}
        <div className="mt-6 p-4 bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl shadow-[0_0_20px_rgba(255,255,255,0.05),0_4px_15px_rgba(0,0,0,0.4),inset_0_1px_1px_rgba(255,255,255,0.15),inset_0_-1px_1px_rgba(0,0,0,0.25)]">
          <h4 className="mb-2 flex items-center gap-2">
            <Shield className="w-4 h-4 text-green-500" />
            Dicas de segurança
          </h4>
          <ul className="space-y-2 text-sm text-gray-400">
            <li className="flex items-start gap-2">
              <span className="text-green-500 mt-0.5">•</span>
              <span>Use uma senha forte e única</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-green-500 mt-0.5">•</span>
              <span>Ative a autenticação de dois fatores</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-green-500 mt-0.5">•</span>
              <span>Nunca compartilhe suas credenciais</span>
            </li>
          </ul>
        </div>

        {/* DEBUG: Permissões (temporário) */}
        <div className="mt-6 p-4 bg-orange-500/10 border border-orange-500/20 rounded-2xl backdrop-blur-md">
          <h4 className="mb-3 flex items-center gap-2 text-orange-400">
            <AlertTriangle className="w-4 h-4" />
            DEBUG: Permissões
          </h4>
          
          {/* Status atual */}
          <div className="mb-4 p-3 bg-white/5 rounded-xl text-xs space-y-1">
            <div className="flex justify-between">
              <span className="text-gray-400">Permissões solicitadas:</span>
              <span className={userData?.permissionsRequested ? 'text-green-400' : 'text-red-400'}>
                {userData?.permissionsRequested ? 'SIM' : 'NÃO'}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Localização:</span>
              <span className="text-white">{userData?.locationPermission || 'não definido'}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Câmera:</span>
              <span className="text-white">{userData?.cameraPermission || 'não definido'}</span>
            </div>
          </div>

          {/* Botões de teste */}
          <div className="space-y-2">
            <button
              onClick={handleRequestPermissionsNow}
              className="w-full bg-orange-500/20 border border-orange-500/30 text-orange-400 py-3 rounded-xl text-sm active:scale-95 transition-transform flex items-center justify-center gap-2"
            >
              <Camera className="w-4 h-4" />
              Solicitar Permissões AGORA
            </button>
            
            <button
              onClick={handleResetPermissions}
              disabled={isResetting}
              className="w-full bg-white/5 border border-white/10 text-white/60 py-3 rounded-xl text-sm active:scale-95 transition-transform disabled:opacity-50 flex items-center justify-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              {isResetting ? 'Resetando...' : 'Resetar Permissões'}
            </button>
          </div>

          <p className="mt-3 text-[10px] text-orange-400/60">
            Após resetar, faça logout e login novamente para testar o fluxo completo
          </p>

          {/* Instruções para desbloquear */}
          {(userData?.locationPermission === 'denied' || userData?.cameraPermission === 'denied') && (
            <div className="mt-4 p-3 bg-red-500/10 border border-red-500/20 rounded-xl">
              <h5 className="text-xs text-red-400 mb-2 flex items-center gap-2">
                <AlertTriangle className="w-3 h-3" />
                Como desbloquear permissões
              </h5>
              <div className="text-[10px] text-white/60 space-y-2">
                <p className="font-medium text-white/80">📱 No Chrome (Android):</p>
                <ol className="list-decimal list-inside space-y-1 ml-2">
                  <li>Toque no ícone de cadeado/informações na barra de endereço</li>
                  <li>Toque em "Permissões"</li>
                  <li>Ative "Localização" e "Câmera"</li>
                  <li>Recarregue a página</li>
                </ol>
                
                <p className="font-medium text-white/80 mt-3">🍎 No Safari (iPhone/iPad):</p>
                <div className="bg-red-500/20 p-2 rounded mt-1 mb-2">
                  <p className="text-red-300 text-[9px] mb-1">⚠️ IMPORTANTE: Safari tem restrições rígidas!</p>
                </div>
                
                <p className="text-white/70 mb-1">OPÇÃO 1 - Configurações do Safari:</p>
                <ol className="list-decimal list-inside space-y-1 ml-2">
                  <li>Abra <strong>Ajustes</strong> do iPhone</li>
                  <li>Role até <strong>Safari</strong></li>
                  <li>Em <strong>Câmera</strong> escolha: <span className="text-green-400">"Perguntar"</span></li>
                  <li>Em <strong>Localização</strong> escolha: <span className="text-green-400">"Perguntar"</span></li>
                  <li><strong>Feche o Safari completamente</strong> (deslizar para cima no App Switcher)</li>
                  <li>Abra o Safari novamente e entre no NexCoin</li>
                </ol>

                <p className="text-white/70 mt-2 mb-1">OPÇÃO 2 - Limpar dados do site:</p>
                <ol className="list-decimal list-inside space-y-1 ml-2">
                  <li>Ajustes → Safari → <strong>Avançado</strong></li>
                  <li>Toque em <strong>Dados de Sites</strong></li>
                  <li>Procure o NexCoin e deslize para <strong>Remover</strong></li>
                  <li>Feche e abra o Safari novamente</li>
                </ol>

                <p className="text-white/70 mt-2 mb-1">OPÇÃO 3 - Use outro navegador:</p>
                <ol className="list-decimal list-inside space-y-1 ml-2">
                  <li>Baixe o <strong>Google Chrome</strong> para iOS</li>
                  <li>Abra o NexCoin no Chrome</li>
                  <li>As permissões funcionam melhor no Chrome</li>
                </ol>

                <div className="bg-yellow-500/20 p-2 rounded mt-2">
                  <p className="text-yellow-300 text-[9px]">
                    💡 DICA: Se nada funcionar, use o Chrome no iPhone. Safari tem limitações que não controlamos.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
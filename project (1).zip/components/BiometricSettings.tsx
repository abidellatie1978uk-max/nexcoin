import { useState, useEffect } from 'react';
import { Fingerprint, ChevronRight, AlertCircle, CheckCircle, ExternalLink } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { 
  isBiometricAvailable, 
  hasBiometricRegistered, 
  registerBiometric,
  removeBiometric,
  getBiometricTypeName 
} from '../lib/biometricAuth';
import { toast } from 'sonner@2.0.3';

export function BiometricSettings() {
  const { user, userData } = useAuth();
  const [isAvailable, setIsAvailable] = useState(false);
  const [isRegistered, setIsRegistered] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isRegistering, setIsRegistering] = useState(false);
  const [biometricType, setBiometricType] = useState('Biometria');

  useEffect(() => {
    checkBiometricStatus();
  }, [user]);

  const checkBiometricStatus = async () => {
    if (!user) return;

    setIsLoading(true);
    try {
      const available = await isBiometricAvailable();
      setIsAvailable(available);

      if (available) {
        const registered = await hasBiometricRegistered(user.uid);
        setIsRegistered(registered);
      }

      setBiometricType(getBiometricTypeName());
    } catch (error) {
      console.error('❌ Error checking biometric status:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleToggleBiometric = async () => {
    if (!user || !userData) return;

    if (isRegistered) {
      // Remove biometric
      try {
        await removeBiometric(user.uid);
        setIsRegistered(false);
        toast.success('Biometria desativada', {
          description: 'Autenticação biométrica removida com sucesso',
        });
      } catch (error) {
        toast.error('Erro ao desativar', {
          description: 'Não foi possível remover a biometria',
        });
      }
    } else {
      // Register biometric
      setIsRegistering(true);
      try {
        const userName = userData.name || userData.email || 'Usuário';
        await registerBiometric(user.uid, userName);
        setIsRegistered(true);
        toast.success('Biometria ativada!', {
          description: 'Suas transações agora estão protegidas por biometria',
        });
      } catch (error: any) {
        console.error('❌ Registration error:', error);
        if (error.message?.includes('cancelled')) {
          toast.error('Registro cancelado', {
            description: 'Você cancelou o registro da biometria',
          });
        } else {
          toast.error('Erro ao ativar', {
            description: 'Não foi possível registrar a biometria',
          });
        }
      } finally {
        setIsRegistering(false);
      }
    }
  };

  if (isLoading) {
    return (
      <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center">
            <Fingerprint className="w-5 h-5 text-white/50" />
          </div>
          <div className="flex-1">
            <p className="text-white/50 text-sm">Verificando disponibilidade...</p>
          </div>
        </div>
      </div>
    );
  }

  if (!isAvailable) {
    return (
      <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-4">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center flex-shrink-0">
            <AlertCircle className="w-5 h-5 text-white/50" />
          </div>
          <div className="flex-1">
            <p className="text-white text-sm mb-1">Biometria não disponível</p>
            <p className="text-white/50 text-xs">
              Seu dispositivo não suporta autenticação biométrica ou ela não está configurada nas configurações do sistema.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* Status Card */}
      <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-4">
        <div className="flex items-center gap-3 mb-3">
          <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
            isRegistered ? 'bg-white/10' : 'bg-white/5'
          }`}>
            {isRegistered ? (
              <CheckCircle className="w-5 h-5 text-white" />
            ) : (
              <Fingerprint className="w-5 h-5 text-white/70" />
            )}
          </div>
          <div className="flex-1">
            <p className="text-white">{biometricType}</p>
            <p className="text-xs text-white/50">
              {isRegistered ? 'Ativo' : 'Inativo'}
            </p>
          </div>
          <button
            onClick={handleToggleBiometric}
            disabled={isRegistering}
            className={`px-4 py-2 rounded-full text-sm transition-colors ${
              isRegistered
                ? 'bg-white/10 text-white/70 hover:bg-white/20'
                : 'bg-white text-black hover:bg-white/90'
            } disabled:opacity-50`}
          >
            {isRegistering ? 'Ativando...' : isRegistered ? 'Desativar' : 'Ativar'}
          </button>
        </div>
        
        <p className="text-xs text-white/50">
          {isRegistered 
            ? 'Suas transações sensíveis estão protegidas por autenticação biométrica'
            : 'Ative para confirmar transações sensíveis com sua biometria'
          }
        </p>
      </div>

      {/* Info Card */}
      <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-4">
        <div className="flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-white/50 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm text-white mb-1">Como funciona?</p>
            <p className="text-xs text-white/70">
              Quando ativada, você precisará confirmar transações sensíveis (saques, conversões e transferências) usando {biometricType}. Seus dados biométricos nunca saem do seu dispositivo.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
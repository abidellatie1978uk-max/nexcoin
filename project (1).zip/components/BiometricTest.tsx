/**
 * 🧪 Componente de Teste de Biometria
 * Use para validar rapidamente se a biometria está funcionando
 */

import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { 
  isBiometricAvailable,
  hasBiometricRegistered,
  registerBiometric,
  authenticateBiometric,
  removeBiometric,
  getBiometricTypeName
} from '../lib/biometricAuth';
import { toast } from 'sonner@2.0.3';

export function BiometricTest() {
  const { user, userData } = useAuth();
  const [testResults, setTestResults] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const addResult = (message: string) => {
    setTestResults(prev => [...prev, `${new Date().toLocaleTimeString()}: ${message}`]);
  };

  const runFullTest = async () => {
    if (!user || !userData) {
      toast.error('Você precisa estar autenticado');
      return;
    }

    setIsLoading(true);
    setTestResults([]);

    try {
      // Test 1: Check availability
      addResult('🔍 Verificando disponibilidade...');
      const available = await isBiometricAvailable();
      addResult(available ? '✅ Biometria disponível!' : '❌ Biometria não disponível');
      
      if (!available) {
        setIsLoading(false);
        return;
      }

      const biometricType = getBiometricTypeName();
      addResult(`📱 Tipo detectado: ${biometricType}`);

      // Test 2: Check if already registered
      addResult('🔍 Verificando registro...');
      const isRegistered = await hasBiometricRegistered(user.uid);
      addResult(isRegistered ? '✅ Biometria já registrada' : 'ℹ️ Biometria não registrada');

      // Test 3: Register if not registered
      if (!isRegistered) {
        addResult('📝 Tentando registrar biometria...');
        const userName = userData.name || userData.email || 'Usuário';
        await registerBiometric(user.uid, userName);
        addResult('✅ Biometria registrada com sucesso!');
        toast.success('Biometria registrada!');
      }

      // Test 4: Authenticate
      addResult('🔐 Tentando autenticar...');
      await authenticateBiometric(user.uid);
      addResult('✅ Autenticação bem-sucedida!');
      toast.success('Autenticação bem-sucedida!');

      // Test 5: Optional - Remove (descomente se quiser testar)
      // addResult('🗑️ Removendo credenciais...');
      // await removeBiometric(user.uid);
      // addResult('✅ Credenciais removidas!');

      addResult('🎉 TODOS OS TESTES PASSARAM!');
    } catch (error: any) {
      addResult(`❌ Erro: ${error.message}`);
      toast.error('Erro no teste', { description: error.message });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-black text-white p-6">
      <div className="max-w-2xl mx-auto">
        <h1 className="text-2xl mb-6">🧪 Teste de Biometria</h1>
        
        <div className="space-y-4">
          {/* Test Button */}
          <button
            onClick={runFullTest}
            disabled={isLoading}
            className="w-full py-4 bg-white text-black rounded-2xl hover:bg-white/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? 'Executando testes...' : 'Executar Teste Completo'}
          </button>

          {/* Results */}
          {testResults.length > 0 && (
            <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl p-4">
              <h2 className="text-lg mb-3">Resultados:</h2>
              <div className="space-y-2 font-mono text-xs">
                {testResults.map((result, index) => (
                  <div key={index} className="text-white/70">
                    {result}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Instructions */}
          <div className="bg-blue-500/10 border border-blue-500/20 rounded-2xl p-4">
            <h3 className="text-sm mb-2">ℹ️ Como usar:</h3>
            <ol className="text-xs text-white/70 space-y-1 list-decimal list-inside">
              <li>Certifique-se de estar autenticado</li>
              <li>Clique em "Executar Teste Completo"</li>
              <li>Siga as instruções do dispositivo</li>
              <li>Verifique os resultados abaixo</li>
            </ol>
          </div>

          {/* Quick Actions */}
          <div className="space-y-2">
            <h3 className="text-sm text-white/50">Ações Rápidas:</h3>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={async () => {
                  if (!user) return;
                  const result = await hasBiometricRegistered(user.uid);
                  toast.info('Status', { 
                    description: result ? 'Biometria registrada' : 'Biometria não registrada' 
                  });
                }}
                className="py-3 bg-white/5 text-white rounded-xl text-sm hover:bg-white/10 transition-colors"
              >
                Verificar Status
              </button>
              <button
                onClick={async () => {
                  if (!user || !userData) return;
                  try {
                    const userName = userData.name || userData.email || 'Usuário';
                    await registerBiometric(user.uid, userName);
                    toast.success('Registrado!');
                  } catch (error: any) {
                    toast.error('Erro', { description: error.message });
                  }
                }}
                className="py-3 bg-white/5 text-white rounded-xl text-sm hover:bg-white/10 transition-colors"
              >
                Registrar
              </button>
              <button
                onClick={async () => {
                  if (!user) return;
                  try {
                    await authenticateBiometric(user.uid);
                    toast.success('Autenticado!');
                  } catch (error: any) {
                    toast.error('Erro', { description: error.message });
                  }
                }}
                className="py-3 bg-white/5 text-white rounded-xl text-sm hover:bg-white/10 transition-colors"
              >
                Autenticar
              </button>
              <button
                onClick={async () => {
                  if (!user) return;
                  const confirmed = confirm('Remover credenciais biométricas?');
                  if (!confirmed) return;
                  try {
                    await removeBiometric(user.uid);
                    toast.success('Removido!');
                  } catch (error: any) {
                    toast.error('Erro', { description: error.message });
                  }
                }}
                className="py-3 bg-red-500/20 text-red-500 rounded-xl text-sm hover:bg-red-500/30 transition-colors"
              >
                Remover
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

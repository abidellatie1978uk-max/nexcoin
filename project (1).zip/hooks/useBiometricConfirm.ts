/**
 * 🔐 Hook para confirmar transações sensíveis com biometria
 */

import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { hasBiometricRegistered, authenticateBiometric } from '../lib/biometricAuth';

export function useBiometricConfirm() {
  const { user } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [pendingAction, setPendingAction] = useState<(() => void) | null>(null);

  /**
   * Request biometric confirmation before executing an action
   * @param action - The action to execute after successful biometric confirmation
   * @returns Promise<void>
   */
  const requestBiometricConfirm = async (action: () => void): Promise<void> => {
    if (!user) {
      console.warn('⚠️ User not authenticated');
      // Execute action without biometric if user is not authenticated
      action();
      return;
    }

    try {
      // Check if user has biometric registered
      const hasRegistered = await hasBiometricRegistered(user.uid);
      
      if (!hasRegistered) {
        console.log('ℹ️ Biometric not registered, executing action without confirmation');
        // Execute action without biometric if not registered
        action();
        return;
      }

      // Store pending action and show modal
      setPendingAction(() => action);
      setIsOpen(true);
    } catch (error) {
      console.error('❌ Error checking biometric registration:', error);
      // Execute action anyway if there's an error
      action();
    }
  };

  /**
   * Handle successful biometric confirmation
   */
  const handleConfirm = () => {
    setIsOpen(false);
    if (pendingAction) {
      pendingAction();
      setPendingAction(null);
    }
  };

  /**
   * Handle cancellation
   */
  const handleCancel = () => {
    setIsOpen(false);
    setPendingAction(null);
  };

  return {
    isOpen,
    requestBiometricConfirm,
    handleConfirm,
    handleCancel,
  };
}

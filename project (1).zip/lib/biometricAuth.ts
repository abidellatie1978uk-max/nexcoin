/**
 * 🔐 Biometric Authentication Library
 * 
 * Uses Web Authentication API (WebAuthn) for production-ready biometric authentication
 * Supports: Touch ID, Face ID, Fingerprint sensors, Windows Hello
 * 
 * Security: Biometric data never leaves the device
 * 
 * ⚠️ LIMITATION: WebAuthn requires same-origin context (won't work in cross-origin iframes)
 */

import { db } from './firebase';
import { doc, setDoc, getDoc } from 'firebase/firestore';

export interface BiometricCredential {
  credentialId: string;
  publicKey: string;
  counter: number;
  createdAt: Date;
  lastUsed?: Date;
  deviceInfo?: string;
}

/**
 * Check if we're in an iframe (WebAuthn limitation)
 */
function isInIframe(): boolean {
  try {
    return window.self !== window.top;
  } catch (e) {
    return true;
  }
}

/**
 * Check if biometric authentication is available on this device
 */
export async function isBiometricAvailable(): Promise<boolean> {
  try {
    // Check if in iframe
    if (isInIframe()) {
      console.log('⚠️ WebAuthn not available in iframe context');
      return false;
    }

    // Check if WebAuthn is supported
    if (!window.PublicKeyCredential) {
      console.log('❌ WebAuthn not supported');
      return false;
    }

    // Check if platform authenticator is available (Face ID, Touch ID, etc)
    const available = await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
    console.log('✅ Biometric available:', available);
    return available;
  } catch (error) {
    console.error('❌ Error checking biometric availability:', error);
    return false;
  }
}

/**
 * Register biometric credentials for a user
 */
export async function registerBiometric(userId: string, userName: string): Promise<boolean> {
  try {
    console.log('🔐 Registering biometric for user:', userId);

    // Check availability first
    const available = await isBiometricAvailable();
    if (!available) {
      throw new Error('Biometric authentication not available on this device');
    }

    // Generate challenge (in production, this should come from server)
    const challenge = new Uint8Array(32);
    crypto.getRandomValues(challenge);

    // Create credential options
    const publicKeyCredentialCreationOptions: PublicKeyCredentialCreationOptions = {
      challenge,
      rp: {
        name: 'NexCoin',
        id: window.location.hostname,
      },
      user: {
        id: new TextEncoder().encode(userId),
        name: userName,
        displayName: userName,
      },
      pubKeyCredParams: [
        { alg: -7, type: 'public-key' },  // ES256
        { alg: -257, type: 'public-key' }, // RS256
      ],
      authenticatorSelection: {
        authenticatorAttachment: 'platform',
        requireResidentKey: false,
        userVerification: 'required',
      },
      timeout: 60000,
      attestation: 'none',
    };

    // Create credential
    const credential = await navigator.credentials.create({
      publicKey: publicKeyCredentialCreationOptions,
    }) as PublicKeyCredential;

    if (!credential) {
      throw new Error('Failed to create credential');
    }

    // Get credential data
    const response = credential.response as AuthenticatorAttestationResponse;
    const credentialId = arrayBufferToBase64(credential.rawId);
    const publicKey = arrayBufferToBase64(response.getPublicKey()!);

    // Save to Firestore
    const biometricData: BiometricCredential = {
      credentialId,
      publicKey,
      counter: 0,
      createdAt: new Date(),
      deviceInfo: navigator.userAgent,
    };

    await setDoc(doc(db, 'biometricCredentials', userId), biometricData);

    console.log('✅ Biometric registered successfully');
    return true;
  } catch (error: any) {
    console.error('❌ Error registering biometric:', error);
    
    // User cancelled
    if (error.name === 'NotAllowedError') {
      throw new Error('Biometric registration cancelled');
    }
    
    throw error;
  }
}

/**
 * Authenticate using biometric
 */
export async function authenticateBiometric(userId: string): Promise<boolean> {
  try {
    console.log('🔐 Authenticating with biometric for user:', userId);

    // Check availability
    const available = await isBiometricAvailable();
    if (!available) {
      throw new Error('Biometric authentication not available');
    }

    // Get stored credential
    const credentialDoc = await getDoc(doc(db, 'biometricCredentials', userId));
    if (!credentialDoc.exists()) {
      throw new Error('Biometric not registered. Please register first.');
    }

    const storedCredential = credentialDoc.data() as BiometricCredential;

    // Generate challenge
    const challenge = new Uint8Array(32);
    crypto.getRandomValues(challenge);

    // Create assertion options
    const publicKeyCredentialRequestOptions: PublicKeyCredentialRequestOptions = {
      challenge,
      allowCredentials: [{
        id: base64ToArrayBuffer(storedCredential.credentialId),
        type: 'public-key',
        transports: ['internal'],
      }],
      timeout: 60000,
      userVerification: 'required',
      rpId: window.location.hostname,
    };

    // Get credential
    const assertion = await navigator.credentials.get({
      publicKey: publicKeyCredentialRequestOptions,
    }) as PublicKeyCredential;

    if (!assertion) {
      throw new Error('Authentication failed');
    }

    // Update last used timestamp
    await setDoc(doc(db, 'biometricCredentials', userId), {
      ...storedCredential,
      lastUsed: new Date(),
      counter: storedCredential.counter + 1,
    });

    console.log('✅ Biometric authentication successful');
    return true;
  } catch (error: any) {
    console.error('❌ Error authenticating with biometric:', error);
    
    // User cancelled
    if (error.name === 'NotAllowedError') {
      throw new Error('Authentication cancelled');
    }
    
    throw error;
  }
}

/**
 * Check if user has biometric registered
 */
export async function hasBiometricRegistered(userId: string): Promise<boolean> {
  try {
    const credentialDoc = await getDoc(doc(db, 'biometricCredentials', userId));
    return credentialDoc.exists();
  } catch (error) {
    console.error('❌ Error checking biometric registration:', error);
    return false;
  }
}

/**
 * Remove biometric credentials
 */
export async function removeBiometric(userId: string): Promise<void> {
  try {
    await setDoc(doc(db, 'biometricCredentials', userId), {
      credentialId: '',
      publicKey: '',
      counter: 0,
      createdAt: new Date(),
      removed: true,
    });
    console.log('✅ Biometric credentials removed');
  } catch (error) {
    console.error('❌ Error removing biometric:', error);
    throw error;
  }
}

// ========== Helper Functions ==========

function arrayBufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function base64ToArrayBuffer(base64: string): ArrayBuffer {
  const binaryString = atob(base64);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes.buffer;
}

/**
 * Get biometric type name for display
 */
export function getBiometricTypeName(): string {
  const platform = navigator.platform.toLowerCase();
  const userAgent = navigator.userAgent.toLowerCase();

  if (platform.includes('iphone') || platform.includes('ipad') || platform.includes('mac')) {
    return 'Touch ID / Face ID';
  } else if (userAgent.includes('android')) {
    return 'Impressão Digital';
  } else if (platform.includes('win')) {
    return 'Windows Hello';
  }

  return 'Biometria';
}